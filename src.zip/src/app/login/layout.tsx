"use client";
import { useSession } from "@supabase/auth-helpers-react";
import { useRouter } from "next/navigation";
import { useEffect } from "react";
import AdminSidebar from "../components/AdminSidebar";
import NavBar from "../components/NavBar";

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const session = useSession();
  const router = useRouter();

  // 1. Počas načítavania session zobraz loader
  if (session === undefined) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <span>Načítavam…</span>
      </div>
    );
  }

  // 2. Ak nie je prihlásený, redirect na login
  useEffect(() => {
    if (session === null) {
      router.replace("/login");
    }
  }, [session, router]);

  if (session === null) {
    return null; // Počas redirectu nič nevykresľuj
  }

  // 3. Prihlásený užívateľ, zobraz admin sekciu
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <NavBar />
      <div className="flex flex-1">
        <AdminSidebar />
        <main className="flex-1 p-8">{children}</main>
      </div>
    </div>
  );
}
