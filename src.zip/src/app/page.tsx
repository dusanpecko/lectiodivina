"use client";
import { useLanguage } from "./components/LanguageProvider";
import { translations } from "./i18n";
import { useRouter } from "next/navigation";
import { useState, useEffect } from "react";
import type { Language } from "./components/LanguageProvider"; // pre type safety

function getCountdown(target: Date) {
  const now = new Date();
  const diff = target.getTime() - now.getTime();
  if (diff < 0) return { days: 0, hours: 0, minutes: 0, seconds: 0 };
  return {
    days: Math.floor(diff / (1000 * 60 * 60 * 24)),
    hours: Math.floor((diff / (1000 * 60 * 60)) % 24),
    minutes: Math.floor((diff / (1000 * 60)) % 60),
    seconds: Math.floor((diff / 1000) % 60),
  };
}

export default function HomePage() {
  const { lang, changeLang } = useLanguage();
  const t = translations[lang];
  const router = useRouter();

  const [targetDate] = useState(() => {
    const now = new Date();
    now.setSeconds(
      now.getSeconds() +
        209 * 24 * 60 * 60 +
        14 * 60 * 60 +
        42 * 60 +
        42
    );
    return now;
  });
  const [countdown, setCountdown] = useState(getCountdown(targetDate));

  useEffect(() => {
    const timer = setInterval(() => setCountdown(getCountdown(targetDate)), 1000);
    return () => clearInterval(timer);
  }, [targetDate]);

  return (
    <div className="relative min-h-screen">
      {/* Hero obrázok na pozadí */}
      <img
        src="https://images.unsplash.com/photo-1506744038136-46273834b3fb?auto=format&fit=cover&w=1500&q=80"
        alt="Pozadie"
        className="absolute inset-0 w-full h-full object-cover z-0"
      />
      <div className="absolute inset-0 bg-gradient-to-br from-black/80 via-black/60 to-black/40 z-10"></div>
      
      {/* Hero menu/nav */}
      <div className="relative z-20 px-8 pt-8 flex justify-between items-center">
        <span className="text-2xl font-bold text-white drop-shadow">{t.app_title}</span>
        <div className="flex items-center gap-6">
          <button
            onClick={() => router.push("/login")}
            className="text-white font-medium hover:underline transition"
          >
            {t.admin}
          </button>
          <label htmlFor="lang-select" className="text-white mr-1">{t.select_language}:</label>
          <select
            id="lang-select"
            value={lang}
            onChange={e => changeLang(e.target.value as Language)}
            className="bg-white/70 text-black rounded px-2 py-1"
          >
            <option value="sk">SK</option>
            <option value="cz">CZ</option>
            <option value="en">EN</option>
            <option value="es">ES</option>
          </select>
        </div>
      </div>

      {/* HERO SEKCIA */}
      <section className="relative z-20 flex flex-col justify-center h-[80vh] max-w-4xl mx-auto px-8 pt-16">
        <div className="space-y-4">
          <div className="text-yellow-400 font-bold tracking-widest text-sm mb-2">{t.preparing}</div>
          <h1 className="text-5xl md:text-6xl font-bold text-white mb-4 leading-tight">
            {t.app_title}<br />
            <span className="font-light text-neutral-200">{t.app_subtitle}</span>
          </h1>
          <p className="text-xl text-neutral-200 mb-6">
            {t.app_desc}
          </p>
          <div className="flex gap-8 mb-6">
            <div className="flex flex-col items-center">
              <span className="text-4xl font-bold text-white">{countdown.days}</span>
              <span className="text-sm text-neutral-300 uppercase">{t.days}</span>
            </div>
            <div className="flex flex-col items-center">
              <span className="text-4xl font-bold text-white">{countdown.hours}</span>
              <span className="text-sm text-neutral-300 uppercase">{t.hours}</span>
            </div>
            <div className="flex flex-col items-center">
              <span className="text-4xl font-bold text-white">{countdown.minutes}</span>
              <span className="text-sm text-neutral-300 uppercase">{t.minutes}</span>
            </div>
            <div className="flex flex-col items-center">
              <span className="text-4xl font-bold text-white">{countdown.seconds}</span>
              <span className="text-sm text-neutral-300 uppercase">{t.seconds}</span>
            </div>
          </div>
          <a href="#" className="inline-block px-8 py-3 rounded-full bg-white/90 text-black font-bold text-lg shadow hover:bg-white transition">
            {t.more}
          </a>
        </div>
      </section>
    </div>
  );
}
